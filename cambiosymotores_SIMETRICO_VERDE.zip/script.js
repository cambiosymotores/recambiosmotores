// Efectos básicos (steampunk gif)
document.body.style.backgroundImage = 'url("assets/animations/steampunk.gif")';
document.body.style.backgroundRepeat = 'no-repeat';
document.body.style.backgroundPosition = 'bottom right';
